import { combineReducers } from "redux";

import videos from "./videos";

export default combineReducers({ videos });
