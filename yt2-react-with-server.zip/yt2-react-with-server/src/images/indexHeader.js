export const Header1 = require('./header-1.png');
export const Header2 = require('./header-2.png');
export const Logo = require('./header-1.png');
export const IconSearch = require('./icon-search-p.png');
export const Header3 = require('./header-3.png');
export const Header4 = require('./header-4.png');
export const Header5 = require('./header-5.png');
export const Header6 = require('./header-6.png');

