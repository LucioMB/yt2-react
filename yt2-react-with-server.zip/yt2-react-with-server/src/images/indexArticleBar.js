export const Iscrizione1 = require('./iscrizione-1.png');
export const Iscrizione2 = require('./iscrizione-2.png');
export const Iscrizione3 = require('./iscrizione-3.png');
export const Iscrizione4 = require('./iscrizione-4.png');
export const Iscrizione5 = require('./iscrizione-5.png');
export const Iscrizione6 = require('./iscrizione-6.png');
export const Iscrizione7 = require('./iscrizione-7.png');
export const Iscrizione8 = require('./iscrizione-8.png');
