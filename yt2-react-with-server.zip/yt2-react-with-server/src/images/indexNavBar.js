export const Home = require('./home.png');
export const Tendenze = require('./tendenze.png');
export const Iscrizioni = require('./iscrizioni.png');

export const Raccolta = require('./raccolta.png');
export const Cronologia = require('./cronologia.png');
export const GuardoPiuTardi = require('./guardo-piu-tardi.png');
export const VideoPiaciuti = require('./video-piaciuti.png');
export const Playlist = require('./playlist.png');

export const Iscrizione1 = require('./iscrizione-1.png');
export const Iscrizione2 = require('./iscrizione-2.png');
export const Iscrizione3 = require('./iscrizione-3.png');
export const Iscrizione4 = require('./iscrizione-4.png');
export const Iscrizione5 = require('./iscrizione-5.png');
export const Iscrizione6 = require('./iscrizione-6.png');
export const Iscrizione7 = require('./iscrizione-7.png');
export const Iscrizione8 = require('./iscrizione-8.png');
export const MostraMeno = require('./mostra-meno.png');

export const Premium = require('./premium.png');
export const Film = require('./film.png');
export const Videogiochi = require('./videogiochi.png');
export const DalVivo = require('./dal-vivo.png');

export const Impostazioni = require('./impostazioni.png');
export const Segnalazioni = require('./segnalazioni.png');
export const Guida = require('./guida.png');
export const Feedback = require('./feedback.png');
