export const videosLoaded = videos => ({ type: "VIDEOS_LOADED", payload: videos });
